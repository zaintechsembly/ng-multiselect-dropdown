/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-multiselect-dropdown-standalone" />
export * from './public_api';
